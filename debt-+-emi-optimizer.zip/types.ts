
export interface LoanParams {
  principal: number;
  rate: number;
  tenure: number;
  extraPayment: number;
}

export interface AmortizationData {
  month: number;
  openingBalance: number;
  emi: number;
  principalPaid: number;
  interestPaid: number;
  closingBalance: number;
  extraPayment: number;
}

export interface ScenarioSummary {
  schedule: AmortizationData[];
  totalInterest: number;
  totalPayment: number;
  tenureInMonths: number;
  emi: number;
}

export interface CalculationResults {
  original: ScenarioSummary;
  optimized: ScenarioSummary;
  interestSaved: number;
  monthsSaved: number;
}
