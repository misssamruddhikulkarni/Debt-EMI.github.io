
import React, { useState } from 'react';
import type { LoanParams } from '../types';

interface LoanInputFormProps {
    initialParams: LoanParams;
    onCalculate: (params: LoanParams) => void;
}

const formatNumber = (num: number) => new Intl.NumberFormat('en-IN').format(num);

export const LoanInputForm: React.FC<LoanInputFormProps> = ({ initialParams, onCalculate }) => {
    const [params, setParams] = useState<LoanParams>(initialParams);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setParams(prev => ({
            ...prev,
            [name]: Number(value) < 0 ? 0 : Number(value)
        }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onCalculate(params);
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-6">
            <h2 className="text-xl font-semibold text-slate-800 border-b pb-3">Loan Details</h2>
            
            <div>
                <label htmlFor="principal" className="block text-sm font-medium text-slate-700">Loan Amount (₹)</label>
                <input
                    type="number"
                    name="principal"
                    id="principal"
                    value={params.principal}
                    onChange={handleChange}
                    className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                    required
                    min="1"
                />
                <p className="text-xs text-slate-500 mt-1">₹ {formatNumber(params.principal)}</p>
            </div>

            <div>
                <label htmlFor="rate" className="block text-sm font-medium text-slate-700">Annual Interest Rate (%)</label>
                <input
                    type="number"
                    name="rate"
                    id="rate"
                    value={params.rate}
                    onChange={handleChange}
                    step="0.01"
                    className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                    required
                    min="0"
                />
            </div>
            
            <div>
                <label htmlFor="tenure" className="block text-sm font-medium text-slate-700">Loan Tenure (Years)</label>
                <input
                    type="number"
                    name="tenure"
                    id="tenure"
                    value={params.tenure}
                    onChange={handleChange}
                    className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                    required
                    min="1"
                />
            </div>

            <div>
                <label htmlFor="extraPayment" className="block text-sm font-medium text-slate-700">Extra Monthly Payment (₹)</label>
                <input
                    type="number"
                    name="extraPayment"
                    id="extraPayment"
                    value={params.extraPayment}
                    onChange={handleChange}
                    className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                    min="0"
                />
                 <p className="text-xs text-slate-500 mt-1">₹ {formatNumber(params.extraPayment)}</p>
            </div>

            <button
                type="submit"
                className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors"
            >
                Calculate & Optimize
            </button>
        </form>
    );
};
