
import React, { useState } from 'react';
import type { AmortizationData } from '../types';

interface AmortizationTableProps {
    originalData: AmortizationData[];
    optimizedData: AmortizationData[] | null;
    onShare: () => void;
    onExport: (format: 'csv' | 'pdf') => void;
    showShareConfirmation: boolean;
}

const formatCurrency = (value: number) => new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
}).format(value);

const ShareIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12s-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.368a3 3 0 105.367 2.684 3 3 0 00-5.367-2.684z" />
  </svg>
);

const DownloadIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
  </svg>
);


const TableView: React.FC<{ data: AmortizationData[], caption: string }> = ({ data, caption }) => (
    <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-slate-200">
            <caption className="py-2 text-lg font-semibold text-left text-slate-700">{caption}</caption>
            <thead className="bg-slate-50">
                <tr>
                    {['Month', 'Opening Balance', 'EMI', 'Principal', 'Interest', 'Extra Payment', 'Closing Balance'].map(header => (
                        <th key={header} scope="col" className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">{header}</th>
                    ))}
                </tr>
            </thead>
            <tbody className="bg-white divide-y divide-slate-200">
                {data.map((row) => (
                    <tr key={row.month} className="hover:bg-slate-50">
                        <td className="px-4 py-3 whitespace-nowrap text-sm font-medium text-slate-900">{row.month}</td>
                        <td className="px-4 py-3 whitespace-nowrap text-sm text-slate-500">{formatCurrency(row.openingBalance)}</td>
                        <td className="px-4 py-3 whitespace-nowrap text-sm text-slate-500">{formatCurrency(row.emi)}</td>
                        <td className="px-4 py-3 whitespace-nowrap text-sm text-green-600">{formatCurrency(row.principalPaid)}</td>
                        <td className="px-4 py-3 whitespace-nowrap text-sm text-red-600">{formatCurrency(row.interestPaid)}</td>
                        <td className="px-4 py-3 whitespace-nowrap text-sm text-blue-600">{formatCurrency(row.extraPayment)}</td>
                        <td className="px-4 py-3 whitespace-nowrap text-sm text-slate-500">{formatCurrency(row.closingBalance)}</td>
                    </tr>
                ))}
            </tbody>
        </table>
    </div>
);


export const AmortizationTable: React.FC<AmortizationTableProps> = ({ originalData, optimizedData, onShare, onExport, showShareConfirmation }) => {
    const [activeTab, setActiveTab] = useState<'original' | 'optimized'>('original');
    
    const showTabs = !!optimizedData;

    return (
        <div className="bg-white p-4 sm:p-6 rounded-xl shadow-lg">
             <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-4 gap-4">
                <h2 className="text-xl font-semibold text-slate-800">Amortization Schedule</h2>
                <div className="flex items-center space-x-2 relative">
                    <button onClick={onShare} className="flex items-center px-4 py-2 border border-slate-300 rounded-md shadow-sm text-sm font-medium text-slate-700 bg-white hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors">
                        <ShareIcon /> Share
                    </button>
                    {showShareConfirmation && <div className="absolute -top-10 right-0 bg-green-500 text-white text-xs px-2 py-1 rounded">Link Copied!</div>}
                    <button onClick={() => onExport('csv')} className="flex items-center px-4 py-2 border border-slate-300 rounded-md shadow-sm text-sm font-medium text-slate-700 bg-white hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors">
                        <DownloadIcon /> CSV
                    </button>
                    <button onClick={() => onExport('pdf')} className="flex items-center px-4 py-2 border border-slate-300 rounded-md shadow-sm text-sm font-medium text-slate-700 bg-white hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors">
                        <DownloadIcon /> PDF
                    </button>
                </div>
            </div>
            
            {showTabs && (
                <div className="border-b border-slate-200 mb-4">
                    <nav className="-mb-px flex space-x-6" aria-label="Tabs">
                        <button
                            onClick={() => setActiveTab('optimized')}
                            className={`${activeTab === 'optimized' ? 'border-indigo-500 text-indigo-600' : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'} whitespace-nowrap py-3 px-1 border-b-2 font-medium text-sm`}
                        >
                            Optimized Schedule
                        </button>
                        <button
                            onClick={() => setActiveTab('original')}
                            className={`${activeTab === 'original' ? 'border-indigo-500 text-indigo-600' : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'} whitespace-nowrap py-3 px-1 border-b-2 font-medium text-sm`}
                        >
                            Original Schedule
                        </button>
                    </nav>
                </div>
            )}
            
            <div className="max-h-[600px] overflow-y-auto">
                {(!showTabs || activeTab === 'original') && <TableView data={originalData} caption="Original Loan Repayment" />}
                {(showTabs && activeTab === 'optimized') && <TableView data={optimizedData} caption="Optimized Loan Repayment" />}
            </div>
        </div>
    );
};
