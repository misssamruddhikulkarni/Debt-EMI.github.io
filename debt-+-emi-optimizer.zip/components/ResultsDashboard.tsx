
import React from 'react';
import { ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, BarChart, Bar } from 'recharts';
import type { CalculationResults } from '../types';

interface ResultsDashboardProps {
    results: CalculationResults | null;
}

const formatCurrency = (value: number) => `₹${new Intl.NumberFormat('en-IN', { maximumFractionDigits: 0 }).format(value)}`;
const formatYearsMonths = (totalMonths: number) => {
    const years = Math.floor(totalMonths / 12);
    const months = totalMonths % 12;
    return `${years}Y ${months}M`;
};

const SummaryCard: React.FC<{ title: string; value: string; subValue?: string; className?: string }> = ({ title, value, subValue, className = '' }) => (
    <div className={`bg-white p-4 rounded-lg shadow-md ${className}`}>
        <h3 className="text-sm font-medium text-slate-500">{title}</h3>
        <p className="text-2xl font-bold text-slate-800 mt-1">{value}</p>
        {subValue && <p className="text-xs text-slate-500 mt-1">{subValue}</p>}
    </div>
);

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-white p-2 border border-slate-200 rounded shadow-sm">
        <p className="label font-bold">{`Month ${label}`}</p>
        {payload.map((pld: any) => (
            <p key={pld.dataKey} style={{ color: pld.color }}>
                {`${pld.name}: ${formatCurrency(pld.value)}`}
            </p>
        ))}
      </div>
    );
  }
  return null;
};

export const ResultsDashboard: React.FC<ResultsDashboardProps> = ({ results }) => {
    if (!results) return null;

    const { original, optimized, interestSaved, monthsSaved } = results;
    const isOptimized = monthsSaved > 0;

    const pieData = [
        { name: 'Principal Amount', value: original.totalPayment - original.totalInterest },
        { name: 'Total Interest', value: original.totalInterest },
    ];
    const COLORS = ['#4f46e5', '#f59e0b'];

    const lineChartData = original.schedule.map((_, i) => ({
        month: i + 1,
        Original: original.schedule[i]?.closingBalance ?? 0,
        Optimized: isOptimized ? (optimized.schedule[i]?.closingBalance ?? 0) : undefined,
    }));
    
    const barChartData = [
        { name: 'Original', 'Total Interest': original.totalInterest },
        { name: 'With Extra Payments', 'Total Interest': optimized.totalInterest },
    ];


    return (
        <div className="space-y-8">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <SummaryCard title="Monthly EMI" value={formatCurrency(original.emi)} />
                <SummaryCard title="Total Interest" value={formatCurrency(isOptimized ? optimized.totalInterest : original.totalInterest)} subValue={isOptimized ? `Original: ${formatCurrency(original.totalInterest)}` : ''}/>
                <SummaryCard title="Loan Tenure" value={formatYearsMonths(isOptimized ? optimized.tenureInMonths : original.tenureInMonths)} subValue={isOptimized ? `Original: ${formatYearsMonths(original.tenureInMonths)}`: ''} />
                <SummaryCard title="Interest Saved" value={formatCurrency(interestSaved)} subValue={`${monthsSaved} months saved`} className="bg-green-50 text-green-800" />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="bg-white p-6 rounded-xl shadow-lg">
                     <h3 className="font-semibold text-lg mb-4">Loan Balance Over Time</h3>
                     <ResponsiveContainer width="100%" height={300}>
                        <LineChart data={lineChartData} margin={{ top: 5, right: 20, left: 20, bottom: 5 }}>
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="month" label={{ value: 'Months', position: 'insideBottom', offset: -5 }} />
                            <YAxis tickFormatter={(tick) => `${(tick / 100000).toFixed(0)}L`} label={{ value: 'Balance (₹)', angle: -90, position: 'insideLeft' }} />
                            <Tooltip content={<CustomTooltip />} />
                            <Legend />
                            <Line type="monotone" dataKey="Original" stroke="#a855f7" strokeWidth={2} dot={false} />
                            {isOptimized && <Line type="monotone" dataKey="Optimized" stroke="#22c55e" strokeWidth={2} dot={false} />}
                        </LineChart>
                     </ResponsiveContainer>
                </div>
                <div className="bg-white p-6 rounded-xl shadow-lg">
                    <h3 className="font-semibold text-lg mb-4">Original Loan Breakdown</h3>
                    <ResponsiveContainer width="100%" height={300}>
                        <PieChart>
                            <Pie data={pieData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={100} fill="#8884d8" label>
                                {pieData.map((entry, index) => <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />)}
                            </Pie>
                            <Tooltip formatter={(value: number) => formatCurrency(value)} />
                            <Legend />
                        </PieChart>
                    </ResponsiveContainer>
                </div>
            </div>
            
            {isOptimized && (
                <div className="bg-white p-6 rounded-xl shadow-lg">
                    <h3 className="font-semibold text-lg mb-4">Interest Savings Comparison</h3>
                    <ResponsiveContainer width="100%" height={300}>
                         <BarChart data={barChartData} layout="vertical" margin={{ top: 5, right: 30, left: 30, bottom: 5 }}>
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis type="number" tickFormatter={(value) => formatCurrency(value)} />
                            <YAxis type="category" dataKey="name" width={120} />
                            <Tooltip formatter={(value: number) => formatCurrency(value)} />
                            <Bar dataKey="Total Interest" fill="#8884d8" background={{ fill: '#eee' }}>
                                <Cell fill="#f59e0b" />
                                <Cell fill="#22c55e" />
                            </Bar>
                        </BarChart>
                    </ResponsiveContainer>
                </div>
            )}
        </div>
    );
};
