
import type { LoanParams, AmortizationData, CalculationResults, ScenarioSummary } from '../types';

function calculateEMI(principal: number, monthlyRate: number, months: number): number {
    if (monthlyRate <= 0) return principal / months;
    const numerator = principal * monthlyRate * Math.pow(1 + monthlyRate, months);
    const denominator = Math.pow(1 + monthlyRate, months) - 1;
    return numerator / denominator;
}

function generateAmortizationSchedule(principal: number, monthlyRate: number, emi: number, tenureInMonths: number, extraPayment: number = 0): ScenarioSummary {
    const schedule: AmortizationData[] = [];
    let openingBalance = principal;
    let totalInterest = 0;
    let totalPayment = 0;

    for (let month = 1; month <= tenureInMonths && openingBalance > 0; month++) {
        const interestPaid = openingBalance * monthlyRate;
        const totalMonthlyPayment = emi + extraPayment;
        let principalPaid = totalMonthlyPayment - interestPaid;
        
        if (openingBalance + interestPaid < totalMonthlyPayment) {
            principalPaid = openingBalance;
        }
        
        const actualEMI = interestPaid + principalPaid - extraPayment;
        
        if(openingBalance < principalPaid){
             principalPaid = openingBalance;
        }

        const closingBalance = openingBalance - principalPaid;

        schedule.push({
            month,
            openingBalance,
            emi: actualEMI,
            principalPaid,
            interestPaid,
            closingBalance: closingBalance < 0 ? 0 : closingBalance,
            extraPayment,
        });

        totalInterest += interestPaid;
        openingBalance = closingBalance;
        totalPayment += actualEMI + extraPayment;
    }
    
    // Adjust totalPayment if loan paid off early
     if (schedule.length > 0) {
        const lastPayment = schedule[schedule.length-1];
        const lastEmi = lastPayment.openingBalance + lastPayment.interestPaid;
        totalPayment = totalPayment - (lastPayment.emi + lastPayment.extraPayment) + lastEmi;
        schedule[schedule.length-1].emi = lastEmi - lastPayment.extraPayment;
        schedule[schedule.length-1].principalPaid = lastPayment.openingBalance;
    }

    return {
        schedule,
        totalInterest,
        totalPayment: principal + totalInterest,
        tenureInMonths: schedule.length,
        emi,
    };
}


export const useLoanCalculator = (params: LoanParams): CalculationResults => {
    const { principal, rate, tenure, extraPayment } = params;

    const monthlyRate = rate / 12 / 100;
    const tenureInMonths = tenure * 12;

    const originalEmi = calculateEMI(principal, monthlyRate, tenureInMonths);
    const originalScenario = generateAmortizationSchedule(principal, monthlyRate, originalEmi, tenureInMonths, 0);

    let optimizedScenario: ScenarioSummary = originalScenario;
    if (extraPayment > 0) {
        optimizedScenario = generateAmortizationSchedule(principal, monthlyRate, originalEmi, tenureInMonths, extraPayment);
    }
    
    const interestSaved = originalScenario.totalInterest - optimizedScenario.totalInterest;
    const monthsSaved = originalScenario.tenureInMonths - optimizedScenario.tenureInMonths;

    return {
        original: originalScenario,
        optimized: optimizedScenario,
        interestSaved,
        monthsSaved,
    };
};
