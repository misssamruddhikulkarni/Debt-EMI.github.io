
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { LoanInputForm } from './components/LoanInputForm';
import { ResultsDashboard } from './components/ResultsDashboard';
import { AmortizationTable } from './components/AmortizationTable';
import { useLoanCalculator } from './hooks/useLoanCalculator';
import type { LoanParams, AmortizationData, CalculationResults } from './types';
import { decodeStateFromHash, encodeStateToHash } from './utils/url';
import { exportToCSV, exportToPDF } from './utils/export';

const App: React.FC = () => {
    const [loanParams, setLoanParams] = useState<LoanParams>({
        principal: 2000000,
        rate: 6.5,
        tenure: 20,
        extraPayment: 0,
    });
    const [results, setResults] = useState<CalculationResults | null>(null);
    const [showShareConfirmation, setShowShareConfirmation] = useState(false);

    const calculate = useCallback((params: LoanParams) => {
        const calcResults = useLoanCalculator(params);
        setResults(calcResults);
    }, []);

    useEffect(() => {
        const initialState = decodeStateFromHash();
        if (initialState) {
            setLoanParams(initialState);
            calculate(initialState);
        } else {
            calculate(loanParams);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const handleCalculate = (params: LoanParams) => {
        setLoanParams(params);
        calculate(params);
    };

    const handleShare = () => {
        const url = encodeStateToHash(loanParams);
        navigator.clipboard.writeText(url).then(() => {
            setShowShareConfirmation(true);
            setTimeout(() => setShowShareConfirmation(false), 2000);
        });
    };
    
    const handleExport = (format: 'csv' | 'pdf') => {
        if (!results) return;
        const dataToExport = loanParams.extraPayment > 0 ? results.optimized.schedule : results.original.schedule;
        if (format === 'csv') {
            exportToCSV(dataToExport, 'amortization_schedule.csv');
        } else {
            exportToPDF(dataToExport, loanParams, results);
        }
    };

    const MemoizedResultsDashboard = useMemo(() => <ResultsDashboard results={results} />, [results]);

    return (
        <div className="bg-slate-50 min-h-screen font-sans text-slate-800">
            <header className="bg-white shadow-md">
                <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-4">
                    <h1 className="text-2xl md:text-3xl font-bold text-slate-900 tracking-tight">Debt & EMI Optimizer</h1>
                    <p className="text-slate-600 mt-1">Visualize your loan repayment and save money with extra payments.</p>
                </div>
            </header>

            <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
                    <div className="lg:col-span-1 bg-white p-6 rounded-xl shadow-lg sticky top-8">
                        <LoanInputForm initialParams={loanParams} onCalculate={handleCalculate} />
                    </div>

                    <div className="lg:col-span-2 space-y-8">
                        {results ? (
                           <>
                            {MemoizedResultsDashboard}
                            <AmortizationTable 
                                originalData={results.original.schedule} 
                                optimizedData={loanParams.extraPayment > 0 ? results.optimized.schedule : null}
                                onShare={handleShare}
                                onExport={handleExport}
                                showShareConfirmation={showShareConfirmation}
                            />
                           </>
                        ) : (
                            <div className="text-center py-20 bg-white rounded-xl shadow-lg">
                                <p className="text-slate-500">Enter your loan details to get started.</p>
                            </div>
                        )}
                    </div>
                </div>
            </main>
            
            <footer className="text-center py-6 mt-8 text-slate-500 text-sm">
                <p>&copy; {new Date().getFullYear()} Debt & EMI Optimizer. All rights reserved.</p>
            </footer>
        </div>
    );
};

export default App;
