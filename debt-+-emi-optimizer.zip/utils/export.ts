
import type { AmortizationData, LoanParams, CalculationResults } from '../types';

// Declare jsPDF and its plugin to satisfy TypeScript since they are loaded from a CDN
declare const jspdf: any;

const formatCurrency = (value: number) => new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: 2,
}).format(value);

export const exportToCSV = (data: AmortizationData[], filename: string) => {
    const headers = ['Month', 'Opening Balance', 'EMI', 'Principal Paid', 'Interest Paid', 'Extra Payment', 'Closing Balance'];
    const csvRows = [
        headers.join(','),
        ...data.map(row => [
            row.month,
            row.openingBalance.toFixed(2),
            row.emi.toFixed(2),
            row.principalPaid.toFixed(2),
            row.interestPaid.toFixed(2),
            row.extraPayment.toFixed(2),
            row.closingBalance.toFixed(2)
        ].join(','))
    ];

    const csvString = csvRows.join('\n');
    const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    if (link.download !== undefined) {
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', filename);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
};

export const exportToPDF = (data: AmortizationData[], params: LoanParams, results: CalculationResults) => {
    const { jsPDF } = jspdf;
    const doc = new jsPDF();

    doc.setFontSize(18);
    doc.text('Amortization Schedule Report', 14, 22);
    
    doc.setFontSize(11);
    doc.setTextColor(100);

    const summaryText = `
    Loan Amount: ${formatCurrency(params.principal)}
    Interest Rate: ${params.rate}% per annum
    Original Tenure: ${params.tenure} years
    Extra Monthly Payment: ${formatCurrency(params.extraPayment)}
    
    Total Interest Saved: ${formatCurrency(results.interestSaved)}
    Tenure Reduced By: ${results.monthsSaved} months
    `;
    doc.text(summaryText, 14, 32);

    const tableColumn = ['Month', 'Opening Balance', 'EMI', 'Principal', 'Interest', 'Extra', 'Closing Balance'];
    const tableRows: (string | number)[][] = [];

    data.forEach(row => {
        const rowData = [
            row.month,
            formatCurrency(row.openingBalance),
            formatCurrency(row.emi),
            formatCurrency(row.principalPaid),
            formatCurrency(row.interestPaid),
            formatCurrency(row.extraPayment),
            formatCurrency(row.closingBalance)
        ];
        tableRows.push(rowData);
    });

    doc.autoTable({
        head: [tableColumn],
        body: tableRows,
        startY: 70,
        theme: 'striped',
        headStyles: { fillColor: [79, 70, 229] }, // Indigo color
    });
    
    doc.save('amortization_schedule.pdf');
};
