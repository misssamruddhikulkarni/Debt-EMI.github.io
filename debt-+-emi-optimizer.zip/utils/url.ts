
import type { LoanParams } from '../types';

export const encodeStateToHash = (params: LoanParams): string => {
    try {
        const jsonString = JSON.stringify(params);
        const base64String = btoa(jsonString);
        const url = new URL(window.location.href);
        url.hash = base64String;
        return url.href;
    } catch (error) {
        console.error("Failed to encode state:", error);
        return window.location.href;
    }
};

export const decodeStateFromHash = (): LoanParams | null => {
    try {
        const hash = window.location.hash.substring(1);
        if (!hash) {
            return null;
        }
        const jsonString = atob(hash);
        const params = JSON.parse(jsonString);

        // Basic validation
        if (
            typeof params.principal === 'number' &&
            typeof params.rate === 'number' &&
            typeof params.tenure === 'number' &&
            typeof params.extraPayment === 'number'
        ) {
            return params;
        }
        return null;
    } catch (error) {
        console.error("Failed to decode state from hash:", error);
        // Clear invalid hash
        window.history.replaceState(null, '', window.location.pathname + window.location.search);
        return null;
    }
};
